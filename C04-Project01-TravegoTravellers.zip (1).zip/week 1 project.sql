-- 2) Perform read operation on the designed table created in the above task using SQL script. 

# a. How many females and how many male passengers traveled a minimum distance of 600 KMs?
SELECT
    Gender,
    COUNT(*) AS total_passengers
FROM
    passanger
WHERE
    Distance >= 600
GROUP BY
    gender
ORDER BY
    total_passengers DESC;

# b. Find the minimum ticket price of a Sleeper Bus.
select 
       min(Price) as minimum_price 
from 
       price
where 
       Bus_Type = 'Sleeper';
       
# c. Select passenger names whose names start with character 'S'
select
      Passenger_name  
from 
      passanger
where 
      Passenger_name like "s%";
      
# d. Calculate price charged for each passenger displaying Passenger name, Boarding City, Destination City, Bus_Type, Price in the output
select
        Passenger_name, Boarding_City, Destination_aty,p.bus_Type, Price
from 
        passanger p
JOIN
    price pr ON p.Bus_Type = pr.Bus_Type;

# e. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus?
SELECT
    p.Passenger_name AS Passenger_Name,
    p.Bus_Type,
    pr.Price
FROM
    passanger p
JOIN
    price pr ON p.Bus_Type = pr.Bus_Type
WHERE
    p.Distance = 1000
    AND p.Bus_Type = 'Sitting';

      
# f. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji?
SELECT
    p.Passenger_name,
    p.Bus_Type,
    p.Boarding_City,
    p.Destination_aty,
    pr.Price
FROM
    passanger p
JOIN
    price pr ON p.Bus_Type = pr.Bus_Type AND p.Distance = pr.Distance
WHERE
    p.Passenger_name = 'Pallavi'
    AND p.Boarding_City = 'Bengaluru'
    AND p.Destination_aty = 'Panaji';


# g. List the distances from the "Passenger" table which are unique (non-repeated distances) in descending order.
select
      distinct(Distance) as uniquedistance
from
      passanger
order by
      uniquedistance desc;

# h. Display the passenger name and percentage of distance traveled by that passenger from the total distance traveled by all passengers
-- without using user variables
SELECT
    Passenger_name,
    (Distance * 100 / (SELECT SUM(Distance) FROM passanger)) AS Percentage_of_Total_Distance
FROM
    passanger order by Percentage_of_Total_Distance desc;