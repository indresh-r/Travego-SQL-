use travego;

# a. How many female passengers traveled a minimum distance of 600 KMs? (1 mark)
SELECT * FROM Passenger
WHERE gender = 'F' AND distance >= 600;

# b. Write a query to display the passenger details whose travel distance is greater than 500 and who are traveling in
 -- a sleeper bus. (2 marks)
SELECT * FROM Passenger
WHERE distance > 500 AND bus_type = 'Sleeper';

 # c. Select passenger names whose names start with the character 'S'. (2 marks)
SELECT name FROM Passenger
WHERE name LIKE 'S%';

#d. Calculate the price charged for each passenger, displaying the Passenger name, Boarding City, 
-- Destination City, Bus type, and Price in the output. (3 marks)
SELECT p.name, p.boarding_city, p.destination_city, p.bus_type, pr.price
FROM Passenger p
JOIN Price pr ON p.bus_type = pr.bus_type AND p.distance = pr.distance;

# e. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs sitting in a bus? (4 marks)
SELECT p.name, pr.price
FROM Passenger p
JOIN Price pr ON p.bus_type = pr.bus_type AND p.distance = pr.distance
WHERE p.distance = 1000 AND p.bus_type = 'Sitting';

# f. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji? (5 marks)
SELECT pr.bus_type, pr.price
FROM Passenger p
JOIN Price pr ON p.bus_type = pr.bus_type AND p.distance = pr.distance
WHERE p.name = 'Pallavi' AND p.boarding_city = 'Bangalore' AND p.destination_city = 'Panaji';

# Alter the column category with the value "Non-AC" where the Bus_Type is sleeper. (2 marks)
UPDATE Passenger
SET category = 'Non-AC'
WHERE bus_type = 'Sleeper';

select * from passenger;

# h. Delete an entry from the table where the passenger name is Piyush and commit this change in the database. (1 mark)
DELETE FROM Passenger
WHERE name = 'Piyush';

COMMIT;

select * from passenger;

# i. Truncate the table passenger and comment on the number of rows in the table (explain if required). (1 mark)
TRUNCATE TABLE Passenger;

-- The number of rows is now 0
# j. Delete the table passenger from the database. (1 mark)
DROP TABLE Passenger;

